#ifndef __MyTypes_H
#define __MyTypes_H

#define base 0x1000		  	// Osnovanie sistemy schislenija

//#define DecBase				// Ispolzyjy 10-tichnyjy zapis 
#define HexBase				// Ispolzyjy 16-tichnyjy zapis

#define DeltaIndex 16		// Shag yvelichenija razriadnosti chisla
#define MaxRazr   128//512
typedef unsigned char byte;
typedef unsigned int  word;
typedef unsigned long dword;

#endif

#ifndef __Profiler
#define __Profiler

#include <time.h>
#define TimeDim 11

extern time_t Time[TimeDim];
extern void ResetTime();

#endif

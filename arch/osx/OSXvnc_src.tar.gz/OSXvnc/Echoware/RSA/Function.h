#ifndef __FUNCTION_H
#define __FUNCTION_H

#include "HNumber.h"
extern int LL(HugeNumber &q);
//extern word NOD(unsigned long uu, unsigned long vv);
//extern int SimplyN(word k);
//extern word SNumber(word k0);
extern HugeNumber FastPower(HugeNumber &a, HugeNumber &b);
extern HugeNumber Pow2m1(HugeNumber &q);
//extern void Error();
#endif

#include "StdAfx.h"
#include "LocalProxyConnection.h"

CLocalProxyConnection::CLocalProxyConnection(void)
{
}

CLocalProxyConnection::~CLocalProxyConnection(void)
{
}

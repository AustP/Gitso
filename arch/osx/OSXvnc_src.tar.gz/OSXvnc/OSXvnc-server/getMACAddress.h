/*
 *  getMACAddress.h
 *  Eggplant
 *
 *  Created by Douglas Simons on 11/15/06.
 *  Copyright 2006 Redstone Software, Inc. All rights reserved.
 *
 */

#import <Foundation/NSString.h>

extern NSString *getMACAddressString();

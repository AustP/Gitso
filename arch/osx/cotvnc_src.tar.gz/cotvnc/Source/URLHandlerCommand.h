//
//  URLHandlerCommand.h
//  Chicken of the VNC
//
//  Created by Jared McIntyre on Sun Feb 01 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface URLHandlerCommand : NSScriptCommand {

}

@end

//
//  NSObject_Chicken.h
//  Chicken of the VNC
//
//  Created by Jason Harris on 8/20/04.
//  Copyright 2004 Geekspiff. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSObject (Chicken)

- (id)deepMutableCopy;

@end

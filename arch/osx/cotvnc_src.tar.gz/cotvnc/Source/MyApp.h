//
//  MyApp.h
//  Chicken of the VNC
//
//  Created by Jason Harris on 12/8/04.
//  Copyright 2004 Geekspiff. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MyApp : NSApplication

@end

//
//  FullscreenWindow.m
//  Chicken of the VNC
//
//  Created by Jason Harris on Tue Sep 24 2002.
//  Copyright (c) 2002 Geekspiff. All rights reserved.
//

#import "FullscreenWindow.h"


// file added by jason - see the header for details

@implementation FullscreenWindow

- (BOOL)canBecomeKeyWindow
{
	return YES;
}

@end

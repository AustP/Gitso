//
//  FullscreenWindow.h
//  Chicken of the VNC
//
//  Created by Jason Harris on Tue Sep 24 2002.
//  Copyright (c) 2002 Geekspiff. All rights reserved.
//

#import <AppKit/AppKit.h>


// Jason added the FullscreenWindow so we can have a borderless window that responds to keyboard events
@interface FullscreenWindow : NSWindow

@end

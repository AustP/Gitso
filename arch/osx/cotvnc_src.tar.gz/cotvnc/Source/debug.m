/*
 *  debug.c
 *  Chicken of the VNC
 *
 *  Created by Kurt Werle on Thu Dec 19 2002.
 *  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
 *
 */

#import "debug.h"
#import <Foundation/Foundation.h>

void DoNothing(NSString *format, ...) {

}

